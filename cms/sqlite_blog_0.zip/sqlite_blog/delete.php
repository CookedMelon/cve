<!DOCTYPE html>
<html>
<head>
	<title>Delete Article</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<a href="index.php" id="logo">SQLite Blog - Delete Article</a>
	<div class="container">
		<form action="delete2.php" method="get" class="form">
			<select name="id" class='selectable'>
				<?php
					include 'conn.php';
					$sql = "SELECT rowid, * FROM articles";
					$query = $db->query($sql);
					while($row = $query->fetchArray()){
						echo "
							<option value=".$row['rowid'].">".$row['article_title']."</a></option>
						";
					}
				?>
			</select>
			<br><br>
			<input type="submit" value="Delete">
		</form>
		<br><br>
		<a href="index.php">&larr; Back</a>
	</div>
</body>
</html>