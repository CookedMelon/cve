<?php
	//include our connection
	include 'conn.php';

	//delete the row of selected id
	$sql = "DELETE FROM articles WHERE rowid = '".$_GET['id']."'";
	$db->query($sql);

	header('Location: delete.php');
?>