<!DOCTYPE html>
<html>
<head>
	<title>Simple SQLite Blog</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<a href="index.php" id="logo">SQLite Blog</a>
	<div class="container">
		<ul>
		<?php
			include "conn.php";
			$sql = "SELECT rowid, * FROM articles";
			$query = $db->query($sql);
			while($row = $query->fetchArray()){
				echo "
					<li><a href='article.php?id=".$row['rowid']."'>".$row['article_title']."</a> - <small>posted ".date('M d, Y', $row['article_timestamp'])."</small></li>
				";
			}
		?>
		</ul>
		<br><br>
		<small class="pagelink"><a href="add.php">Add Article</a> | <a href="delete.php">Delete Article</a></small>
	</div>
</body>
</html>