<?php
//Create a new SQLite3 Database
$db = new SQLite3('blog.db');

//Create a new table to our database 
$query = "CREATE TABLE IF NOT EXISTS articles (article_title TEXT, article_content TEXT, article_timestamp INTEGER)";
$db->exec($query);

?>