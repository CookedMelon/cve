<?php
	include "conn.php";
	if(empty($_POST["content"]) OR empty($_POST["title"])){
		$error = "All fields are required!";
	}else{
		$sql = "INSERT INTO articles (article_title, article_content, article_timestamp) VALUES ('".$_POST['title']."', '".nl2br($_POST['content'])."', '".time()."')";
		$db->query($sql);
		header('Location: index.php');
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Add New Article</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<a href="index.php" id="logo">SQLite Blog - Add Article</a>
	<div class="container">
		<?php
			if(isset($error)){
				echo "<span style='color:red'>".$error."</span>";
			}
		?>
		<form action="add.php" method="post" class="form">
			<input type="text" name="title" placeholder="Add Article Title">
			<br><br>
			<textarea name="content" placeholder="Add Article Content" rows="15"></textarea>
			<input type="submit" name="save" value="Save" id="save">
		</form>
		<br><br>
		<a href="index.php">&larr; Back</a>
	</div>
</body>
</html>