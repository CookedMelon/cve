<?php
	include "conn.php";
	$sql = "SELECT rowid, * FROM articles WHERE rowid = '".$_GET['id']."'";
	$query = $db->query($sql);
	while($row = $query->fetchArray()){
?>
<!DOCTYPE html>
<html>
<head>
	<title><?php echo $row['article_title']; ?></title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<a href="index.php" id="logo">SQLite Blog</a>
	<div class="container">
		<?php
				echo "
					<h3>".$row['article_title']."  <small>posted ".date('M d, Y', $row['article_timestamp'])."</small></h3>
					<p>".$row['article_content']." </p>
				";
			}
		?>
		<a href="index.php">&larr; Back</a>
	</div>
</body>
</html>