<nav class="navbar navbar-expand-lg navbar-dark bg-primary bg-gradient">
    <div class="container">
        <a class="navbar-brand" href="./">Dynamic Table of Contents - PHP</a>
        
        <div>
            <a href="https://sourcecodester.com" class="text-light fw-bolder h6 text-decoration-none" target="_blank">SourceCodester</a>
        </div>
    </div>
</nav>