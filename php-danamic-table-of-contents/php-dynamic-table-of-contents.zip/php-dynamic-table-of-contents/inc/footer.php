<footer class="bg-gradient bg-light shadow-top py-4 col-auto">
    <div class="">
        <div class="text-center">
            All Rights Reserved &copy; <?= date("Y") ?> | <span class="text-muted">Dynamic Table of Contents App - PHP</span>
        </div>
        <div class="text-center">
            <a href="mailto:oretnom23@gmail.com" class="text-decoration-none text-success">oretnom23@gmail.com</a>
        </div>
    </div>
</footer>